((window) => {
  const component = () => {
    return React.createElement("div", {}, "Hello World");
  };
  window.extensionsAPI.registerAppViewExtension(
    component,
    "*",
    "*",
    "Nice extension"
  );
})(window);